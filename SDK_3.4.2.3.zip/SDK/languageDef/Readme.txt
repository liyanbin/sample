﻿Language definition (.langdef) files are portable files that contain information 
about a particular language.  They can be loaded at runtime via a
SyntaxLanguageDefinitionSerializer to automatically build a syntax language.

Language project (.langproj) files related to the language definitions are included
in the sibling Projects folder.