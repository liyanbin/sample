﻿/**
* @externs
* External definitions : Contextor APIs
* @license ...
*/

var bootstrap = function(name, definition) {}
var ses = function() {
	this.ok = function() {}
}
var process = function() {}
var ReturnValue = function() {}
var StopIteration = function() {}

/**
 * Contextor Script Engine 
 * @constructor
 */
var HostEngine = function() {
	/**
	 * @return {string}
	 * @nosideeffects
	 * @see http://msdn.microsoft.com/en-us/library/9k34bww2(VS.80).aspx
	 */
	this.ScriptEngine = function () {}
	/**
	 * @return {number}
	 * @nosideeffects
	 * @see http://msdn.microsoft.com/en-us/library/yf25ky07(VS.80).aspx
	 */
	this.ScriptEngineMajorVersion = function () {}
	/**
	 * @return {number}
	 * @nosideeffects
	 * @see http://msdn.microsoft.com/en-us/library/wx3812cz(VS.80).aspx
	 */
	this.ScriptEngineMinorVersion = function () {}
	/**
	 * @return {number}
	 * @nosideeffects
	 * @see http://msdn.microsoft.com/en-us/library/e98hsk2f(VS.80).aspx
	 */
	this.ScriptEngineBuildVersion = function () {}
	this.Debug = {
		write : function(txt) {}
	}
	this.MessageBox = function( hwndParent, bstrText, bstrTitre, uiType) {
		return 0;
	}
	this.GetURL = function( strURL ) {
		return "";
	}
	/**
	 * @param {number} timeout
	 */
	this.SetTimeoutValue = function( timeout ) {
		return "";
	}
	/**
	 * @param {Object} obj
	 * @param {string} prefix
	 */
	this.ConnectEvents = function( obj, prefix ) {
		return "";
	}
	/**
	 * @param {Object} obj
	 */
	this.DisconnectEvents = function( obj ) {
		return "";
	}
	/*
	LoadScriptEngine			( [in] BSTR strProgID, [in] IUnknown *pIUnkDebugApplication, [in] IUnknown *pIUnkProcessDebugManager, [in] IDispatch *pDisWrkMng, [out] BSTR *pstrError );
	AddScriptFile				( [in] BSTR strScriptFileName, [in] LONG lScriptIndex, [out, retval] BSTR *pstrError );
	Start						( [out] BSTR *pstrError );
	Quit						( void );
	SetHwndProcess				( [in] long hwnd );
	GetScriptFilePath			( [out] BSTR *strScriptFilePath );
	GetCurrentDir				( [out, retval] BSTR *pstrDir );
	AddScriptText				( [in] BSTR bstrSourceFile, [in] BSTR bstrScriptText, [in] LONG lScriptIndex, [out, retval] BSTR *pstrError );
	Restart						( void );
	GetHwndProcess				( [out, retval] long *phwnd );
	SetDebugger					( [in] long hwnd );
	CsFileDlg					( [in] BSTR bstrTitle, [in] BSTR bstrFilter, [in] BSTR bstrFct, [out, retval] BSTR *pbstrfileName );
	GetDebugger					( [out, retval] long *phwnd );
	GetWkMngObject				( [out,retval] IDispatch **spWkMng );
	SetWkMngObject				( [in] IDispatch *spWkMng );
	ToggleBreakPoint			( [in] ULONG ulContext, [in] LONG lCharOffset, [in] LONG lLength, [in] VARIANT_BOOL bStatus, [out, retval] ULONG *plCharOffset );
	ActivateBreakPoint			( [in] ULONG ulContext, [in] LONG lCharOffset, [in] LONG lLength, [in] VARIANT_BOOL bStatus );
	GetSourceContextFromCookie	( [in] ULONG dwCookie, [out] ULONG *pulContext );
	CurrentSourceContext		( [out, retval] ULONG *pulContext );
	ResumeFromBreakPoint		( [in] LONG lBreakResumeAction );
	GetCurrentProject			( [out, retval] BSTR *pstrCurrentProject );
	SetCurrentProject			( [in] BSTR bstrCurrentProject );
	SetDualScriptEngine			( [in] IDispatch *spDualScriptEngine );
	GetDualScriptEngine			( [out, retval] IDispatch **sppDualScriptEngine );
	GetAlternativeURL			( [out,retval] BSTR *pstrAlternativeURL );
	SetAlternativeURL			( [in] BSTR bstrURL );
	AsyncInvoke					( [in] BSTR bstrMethod, [in] VARIANT *pArgs, [in] UINT uiArgs, [out, retval] VARIANT *pvarResult );
	ScriptDispatch				( [out, retval] IDispatch **ppDispVal );
	Evaluate					( [in] BSTR bstrExpression, [in] IUnknown *pIUnkRemoteDebugApplicationThread, [out, retval] VARIANT *pvarResult );
	CauseBreak					( void );
	*/
};
/** @type {HostEngine} */ var Host;
/** @type {HostEngine} */ var ctxHost;

/** init declarations */
function CtxtCompute (expression) {}
function CtxtEnd ( bRestart ) {}
function CtxtSetCurrentProject (CurrentProject) {}
function CtxtSetAlternativeURL (URL) {}
//function CtxtRestart () {}
function addLog (text) {}
function CtxtAutoRestart (enable) {}

/**
 * Contextor WkMng 
 * //@interface
 * //@constructor
 */
var Contextor = function() {

	this.WkMgTrtEvent2 = function (AppliName, Event, ObjetName, ControlName, lControlIndex, Data, lIdInstanceAppli, lIdInstanceObjet, lIdInstanceItem, pdispOiApp, ReqPrjName, reqAppli, ReqEvent, reqItem, lReqIdInstanceAppli) { return ""; }
	this.WkMgLog = function (Message, lType) { return ""; }
	this.WkMgLogErrSys = function (Message, ler, lerr) { return ""; }
	this.WkMgSelSingleNode = function (queryString) { return ""; }
	this.WkMgNotify = function (CtxName, AppliName, Event, ObjetName, ControlName, lControlIndex, Data, lIdInstanceAppli, lIdInstanceObjet, lIdInstanceItem, pdispOiApp) { return ""; }
	this.CtxtAction = function (Action, AppliName, PageName, Item, lItemIndex, DataIn, lIdAppliInst, lIdPageInst, lIdItemInst) { return ""; }
	this.CtxtActionApp = function (Action, AppliName, PageName, P1, P2, P3, P4, P5, lIdAppliInst, lIdPageInst, lIdItemInst) {	return ""; }
	this.CtxtVerbExec = function (Command, AppliName, PageName, lIdAppliInst, lIdPageInst) { return "";	}
	this.CtxtLogTick = function () { return ""; }
	this.CtxtLogTime = function (vChrono, Mess) { return ""; }
	this.CtxtWriteFile = function (File, Text, vbEnd) { return ""; }
	this.CtxtReadFile = function (File) { return ""; }
	this.CtxtCreateObj = function (Object) { return ""; }
	this.CtxtAutoRestart = function (restart) { return ""; }
	this.LogEvent = function (type, message) { return ""; }
	
	/**
	 * Description
	 * @ignore
	 * @method CtxtGetVal
	 * @param {string} variable
	 * @param {string} nodeCtx
	 * @param {string} idApp
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.CtxtGetVal = function (variable, nodeCtx, idApp, pResult) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CtxtSetVal
	 * @param {string} variable
	 * @param {string} value
	 * @param {string} nodeCtx
	 * @param {string} idApp
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.CtxtSetVal = function (variable, value, nodeCtx, idApp, pResult) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CtxtGetCtx
	 * @param {string} variable
	 * @param {string} nodeCtx
	 * @param {string} idApp
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.CtxtGetCtx = function (variable, nodeCtx, idApp, pResult) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CtxtSetCtx
	 * @param {string} ctxt
	 * @param {string} iAction
	 * @param {string} model
	 * @param {string} iModel
	 * @param {string} nodeCtx
	 * @param {string} idApp
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.CtxtSetCtx = function (ctxt, iAction, model, iModel, nodeCtx, idApp, pResult) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CtxtDelCtx
	 * @param {string} variable
	 * @param {string} nodeCtx
	 * @param {string} idApp
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.CtxtDelCtx = function (variable, nodeCtx, idApp, pResult) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CtxtAddBloc
	 * @param {string} ctxt
	 * @param {string} model
	 * @param {string} iModel
	 * @param {string=} nodeCtx
	 * @param {string=} idApp
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.CtxtAddBloc = function (ctxt, model, iModel, nodeCtx, idApp, pResult) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method WkMgGetPscNode
	 * @param {string} pilote
	 * @param {Object=} pResult
	 * @return {string} result
	 */
	this.WkMgGetPscNode = function (pilote, pResult) { return ""; }

	this.WkMgMessErr = function (Pilote, Fonction, Code, Erreur, lMess) { return ""; }

	/**
	 * Description
	 * @ignore
	 * @method CryptProtect
	 * @param {string} input
	 * @param {string} [password]
	 * @return {string} result
	 */
	this.CryptProtect = function (input, password) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptUnprotect
	 * @param {string} input
	 * @param {string} [password]
	 * @return {string} result
	 */
	this.CryptUnprotect = function (input, password) { return ""; }
	this.CryptEncryptStringToFile = function (inputString, outputFile, password, keyContainer, algorithm, storeLocation) { return ""; }
	this.CryptDecryptFileToString = function (inputFile, password, keyContainer, algorithm, storeLocation) { return ""; }
	this.CryptEncryptFileToFile = function (inputFile, outputFile, password, keyContainer, algorithm, storeLocation) { return ""; }
	this.CryptDecryptFileToFile = function (inputFile, outputFile, password, keyContainer, algorithm, storeLocation) { return ""; }
	this.CryptEncryptStringToString = function (inputString, password, keyContainer, algorithm, storeLocation) { return ""; }
	this.CryptDecryptStringToString = function (inputString, password, keyContainer, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptDecryptMessage
	 * @param {string} input
	 * @param {string} store
	 * @param {string} certificate
	 * @param {string} keyContainer
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptDecryptMessage = function (input, store, certificate, keyContainer, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptEncryptMessage
	 * @param {string} input
	 * @param {string} store
	 * @param {string} certificate
	 * @param {string} keyContainer
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptEncryptMessage = function (input, store, certificate, keyContainer, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptEncryptMessage
	 * @param {string} input
	 * @param {string} publicKey
	 * @param {string} password
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptEncryptWithPublicKey = function (input, publicKey, password, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptSignHashData
	 * @param {string} input
	 * @param {string} store
	 * @param {string} certificate
	 * @param {string} keyContainer
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptSignHashData = function (input, store, certificate, keyContainer, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptSignMessage
	 * @param {string} input
	 * @param {string} store
	 * @param {string} certificate
	 * @param {string} keyContainer
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptSignMessage = function (input, store, certificate, keyContainer, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptVerifyMessage
	 * @param {string} input
	 * @param {string} store
	 * @param {string} certificate
	 * @param {string} keyContainer
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptVerifyMessage = function (input, store, certificate, keyContainer, algorithm, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptVerifyHashData
	 * @param {string} input
	 * @param {string} signature
	 * @param {string} store
	 * @param {string} certificate
	 * @param {string} keyContainer
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {boolean} result
	 */
	this.CryptVerifyHashData = function (input, signature, store, certificate, keyContainer, algorithm, storeLocation) { return false; }
	/**
	 * Description
	 * @ignore
	 * @method CryptVerifyHashData
	 * @param {string} input
	 * @param {string} signature
	 * @param {string} publicKey
	 * @param {string} algorithm
	 * @param {Number} storeLocation
	 * @return {boolean} result
	 */
	this.CryptVerifyHashDataWithPublicKey = function (input, signature, publicKey, algorithm, storeLocation) { return false; }
	/**
	 * Description
	 * @ignore
	 * @method CryptCreateKeyContainer
	 * @param {string} keyContainer
	 * @param {boolean} signatureKey
	 * @param {boolean} exchangeKey
	 * @param {Number} storeLocation
	 * @return {boolean} result
	 */
	this.CryptCreateKeyContainer = function (keyContainer, signatureKey, exchangeKey, storeLocation ) { return false; }
	/**
	 * Description
	 * @ignore
	 * @method CryptCreateKeyContainer
	 * @param {string} keyContainer
	 * @param {Number} storeLocation
	 * @return {boolean} result
	 */
	this.CryptDeleteKeyContainer = function (keyContainer, storeLocation) { return false; }
	/**
	 * Description
	 * @ignore
	 * @method CryptGetExportedKey
	 * @param {string} keyContainer
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptGetExportedKey = function (keyContainer,  storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptCreateKeyContainer
	 * @param {string} keyContainer
	 * @param {boolean} signature
	 * @param {Number} storeLocation
	 * @return {string} result
	 */
	this.CryptGetPublicKey = function (keyContainer, signature, storeLocation) { return ""; }
	/**
	 * Description
	 * @ignore
	 * @method CryptSavePublicKey
	 * @param {string} keyContainer
	 * @param {string} publicKey
	 * @param {boolean} signature
	 * @param {Number} storeLocation
	 * @return {boolean} result
	 */
	this.CryptSavePublicKey = function (keyContainer, publicKey, signature, storeLocation) { return false; }
	this.CryptDeleteCredential = function (name, type) { return false; }
	this.CryptReadCredential = function (name, type) { return ""; }
	this.CryptWriteCredential = function (name, type, persist, userName, password, comment) { return false; }
	
	// methods for 'Contextor' object injected in web pages (Web3 connector)
	this.Log = function (level, text) { return ""; }
	this.Event = function (eventName, appliName, pageName, itemName, instanceAppli, instancePage, data) { return ""; }
	
};

