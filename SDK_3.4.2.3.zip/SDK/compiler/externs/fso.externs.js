﻿

/** TextStream COM object interface
 * @see https://msdn.microsoft.com/en-us/library/312a5kbt(v=vs.84).aspx
 * @constructor
 * @return {TextStream}
 */
function TextStream () { 
 	this.AtEndOfLine = {} 
	this.AtEndOfStream = {} 
	this.Column = {} 
	this.Line = {} 
	this.Close = function() {}
	this.Read = function(characters) {}
	this.ReadAll = function() {} 
	this.ReadLine = function() {}
	this.Skip = function() {}
	this.SkipLine = function() {}
	this.Write = function() {}
	this.WriteBlankLines = function() {}
	this.WriteLine = function() {}
};

/** Drive COM object
 * @constructor
 * @return {DriveObject}
 */
function DriveObject() { 
	this.Files = {};
	this.AvailableSpace = {};
	this.DriveLetter = {};
	this.VolumeName = {};
}

/** File or folder COM object
 * @constructor
 * @return {FolderObject}
 */
function FolderObject() { 
	this.Files = {};
	this.Attributes = {};
	this.DateCreated = {};
	this.DateLastAccessed = {};
	this.DateLastModified = {};
	this.Drive = {};
}

/** File or folder COM object
 * @constructor
 * @return {FileObject}
 */
function FileObject() { 
	this.DateCreated = {};
	this.DateLastAccessed = {};
	this.DateLastModified = {};
	this.Drive = {};
	this.Size = {};
	this.Type = {};
	/** 
		@param {number=} iomode 
		@param {number=} format 
	*/
	this.OpenAsTextStream = function(iomode, format) {};
}

/** Scripting.FileSystemObject COM object
 * @see http://msdn.microsoft.com/en-us/library/aa242706(v=vs.60).aspx
 * @constructor
 * @return { ScriptingFileSystemObject }
 */
function ScriptingFileSystemObject() { 
	/** 
		@param {string} path 
		@param {string} name 
	*/
	this.BuildPath = function(path, name) {}
	this.GetAbsolutePathName = function() {}
	/** 
		@param {string} driveName
		@return {DriveObject} drive Drive object
	*/
	this.DriveExists = function(driveName) {}
	/** 
		@param {string} driveName
		@return {DriveObject} drive Drive object
	*/
	this.GetDrive = function(driveName) {}
	/** 
		@param {string} driveName
		@return {DriveObject} drive Drive object
	*/
	this.GetDriveName = function(driveName) {}
	
	/** 
		@param {string} fileName
		@return {string} absolute file name
	*/
	this.GetAbsolutePathName = function(fileName) {}
	
	/** 
		@param {string} source 
		@param {string} destination 
		@param {boolean=} overwrite
	*/
	this.CopyFolder = function(source, destination, overwrite) {}
	/** 
		@param {string} foldername 
	*/
	this.CreateFolder = function(foldername) {}
	/** 
		@param {string} foldername 
	*/
	this.DeleteFolder = function(foldername) {}

	/** 
		@param {string} folderspec 
	*/
	this.FolderExists = function(folderspec) {}


	/** 
		@param {string} folderspec 
		@return {FolderObject} folder object
	*/
	this.GetFolder = function(folderspec) {}
	
	this.GetParentFolderName = function(folderspec) {}
	this.GetSpecialFolder = function(folderspec) {}

	/** 
		@param {string} source 
		@param {string} destination 
	*/
	this.MoveFolder = function(source, destination) {}

	
	/** 
		@param {string} source 
		@param {string} destination 
	*/
	this.MoveFile = function(source, destination) {}

	/** 
		@param {string} filespec 
	*/
	this.FileExists = function(filespec) {}

	/** 
		@param {string} filename 
	*/
	this.GetBaseName = function(filename) {}
	/** 
	 *@param {Object|string} pathspec 
	 * @return {string}
	 */
	this.GetFileName = function(pathspec) {}
	/** 
		@param {string} filename 
	*/
	this.GetExtensionName = function(filename) {}

	/** 
		@param {string} source 
		@param {string} destination 
		@param {boolean=} overwrite
	*/
	this.CopyFile = function(source, destination, overwrite) {}

	/** 
		@param {Object} source 
		@param {boolean=} force
	*/
	this.DeleteFile = function(source, force) {}
	
	/** 
		@param {string} filename 
		@param {number} iomode 
		@param {boolean} create 
		@param {number=} format 
	*/
	this.OpenTextFile = function(filename, iomode, create, format) {}

	/** 
		@param {string} filename 
		@param {boolean=} overwrite 
		@param {boolean=} unicode 
	*/
	this.CreateTextFile = function(filename, overwrite, unicode) {}
	
	this.GetTempName = function() {}


	/** 
	 *@param {string} filespec 
	 * @return {FileObject}
	 */
	this.GetFile = function(filespec) {}
	
	
	};
	
