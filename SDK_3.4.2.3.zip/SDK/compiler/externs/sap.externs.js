﻿

/** SAPScripting main interface
 * @see ...
 * @constructor
 * @return {SAPScriptingInstance}
 */
function SAPScriptingInstance () { 
 	this.GetScriptingEngine = function() {} 
};

/** SAPScripting Application object interface
 * @see ...
 * @constructor
 * @return {SAPScriptingApplication}
 */
function SAPScriptingApplication () { 
};

/** SAPScripting Connection object interface
 * @see ...
 * @constructor
 * @return {SAPScriptingConnection}
 */
function SAPScriptingConnection () { 
};

/** SAPScripting Session object interface
 * @see ...
 * @constructor
 * @return {SAPScriptingSession}
 */
function SAPScriptingSession () { 
};

/** SAPScripting Object object interface
 * @see ...
 * @constructor
 * @return {SAPScriptingObject}
 */
function SAPScriptingObject () {
	this.currentCellRow = 0;
	this.currentCellColumn = 0;
	this.close = function() {};
	this.iconify = function() {};
	this.restore = function() {};
	this.minimize = function() {};
	this.maximize = function() {};
	this.sendVKey = function(command) {};
	this.doubleClickItem = function(key, value) {};
	this.ensureVisibleHorizontalItem = function(name, value) {};
	this.expandNode= function( key ) {};
	this.getCellValue = function(row, col) { return ''; };
	this.getNodeTextByKey  = function(key) { return ''; }; 
	this.hardCopy  = function(filename, type) { return ''; };	
	this.itemContextMenu = function(name, value) {};
	this.key = '';
	this.modifyCell = function(row, col, value) { return ''; };
	this.press = function() {};
	this.pressEnter = function() {}; 
	this.pressButton = function(buttonName) {};
	this.select = function() {};
	this.selectedItemNode = '';
	this.selected = false;
	this.selectedTab = '';
	this.selectMenuItem = function(command) {};
	this.selectMenuItemByText = function(command) {};
	this.setFocus = function() {};
	this.selectContextMenuItem = function(command) {};
	this.selectItem = function(name, value) {};
	this.showContextMenu = function() {};
	this.visualize = function(show) {};
};
