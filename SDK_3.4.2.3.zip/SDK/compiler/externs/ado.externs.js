﻿


/** ADODB.Stream COM object
 * @see https://msdn.microsoft.com/en-us/library/ms677486(v=vs.85).aspx
 * @constructor
 * @return { ADODBStreamObject }
 */
function ADODBStreamObject() { 
	this.Charset = 0;
	this.EOS = 0;
	this.LineSeparator = 0;
	this.Mode = 0;
	this.Position = 0;
	this.Size = 0;
	this.State = 0;
	this.Type = 0;

	this.Cancel = function() {}
	this.Close = function() {}
	/**
	* @param {ADODBStreamObject} destStream
	* @param {number} [numChars]
	*/
	this.CopyTo = function(destStream, numChars) {}
	this.Flush = function() {}
	this.LoadFromFile = function(path) {}
	/**
	* @param {*} [source]
	* @param {number} [mode]
	* @param {number} [openOptions]
	* @param {string} [userName]
	* @param {string} [password]
	*/
	this.Open = function(source, mode, openOptions, userName, password) {}
	/**
	* @param {number} [numBytes]
	*/
	this.Read = function(numBytes) {}
	/**
	* @param {number} [numBytes]
	*/
	this.ReadText = function(numBytes) {}
	/**
	* @param {string} fileName
	* @param {number} saveOptions
	*/
	this.SaveToFile = function(fileName, saveOptions) {}
	this.SetEOS = function() {}
	this.SkipLine = function() {}
	this.Stat = function(statStg, statFlag) {}
	this.Write = function(buffer) {}
	/**
	* @param {string} data
	* @param {number} [options]
	*/
	this.WriteText = function(data, options) {}
};
	
/** ADODB.Recordset COM object
 * @constructor
 * @return { ADODBRecordsetObject }
 */
function ADODBRecordsetObject() { 
};
