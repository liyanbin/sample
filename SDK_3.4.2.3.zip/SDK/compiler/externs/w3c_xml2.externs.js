﻿
/**
 * @type {Object}
 */
XMLHttpRequest.prototype.responseBody;
 
