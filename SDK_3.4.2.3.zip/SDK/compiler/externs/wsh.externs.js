﻿/**
* @externs
* External definitions : Contextor APIs
* @license ...
*/

/**
 * @param {string} obj
 * @param {string=} id
 * @param {number=} index
 */
function GetObject(obj, id, index){};

function CollectGarbage(){};

/** Enumerator from JScript
 *  @constructor
 */
var Enumerator = function(obj)
{
	this.moveFirst = function() {};
	this.moveNext = function() {};
	this.atEnd = function() {};
	this.item = function() {};
};

/** VBArray 
 *  @constructor
 */
var VBArray = function(obj)
{
	this.dimensions = function() {};
	this.getItem = function() {};
	this.lbound = function(dimension) {};
	this.toArray = function() {};
	this.ubound = function(dimension) {};
};
