﻿
/** WshScript COM object interface
 * @see https://msdn.microsoft.com/en-us/library/ccxe1xe6(v=vs.84).aspx
 * @constructor
 */
function WshScriptClass () { 
	this.ConnectObject = function(objEventSource, strPrefix) {}
}
/** @type {WshScriptClass} */ var WScript;

function ConnectObject(objEventSource, strPrefix) {}

/** WshScriptExec COM object interface
 * @see http://msdn.microsoft.com/en-us/library/aew9yb99%28v=vs.84%29.aspx
 * @constructor
 */
function WshScriptExec () { 
	this.ExitCode = 0;
	this.ProcessID = 0; 
	this.Status = 0;
	/**
	 * @type {TextStream} 
	*/
	this.StdErr = null; 
	/**
	 * @type {TextStream} 
	*/
	this.StdIn = null;
	/**
	 * @type {TextStream} 
	*/
	this.StdOut = null;
	this.Terminate = function() {}
};

/** WshEnvironment COM object interface
 * @see http://msdn.microsoft.com/en-us/library/6s7w15a0(v=vs.84).aspx
 * //@constructor
 * //@param {string=} var
 * @return {string} result
 */
function WshEnvironment() { 
	this.Item = {} 
	this.Length = {} 
	this.Count = function() {}
	this.Remove = function(str) {}
};

/** WshSpecialFolders COM object interface
 * @see http://msdn.microsoft.com/en-us/library/9x9e7edx(v=vs.84).aspx
 * @constructor
 */
function WshSpecialFolders () { 
	this.Item = {} 
	this.Length = {} 
	this.Count = function() {}
};

/** WScript.Shell COM object interface
 * @see http://msdn.microsoft.com/en-us/library/aew9yb99%28v=vs.84%29.aspx
 * @constructor
 * @return {WScriptShell}
 */
function WScriptShell () { 
	this.CurrentDirectory = {};
	/**
	 * @param {string=} type
	 * //@return {WshEnvironment} 
	 * @return {function(string=)} 
	*/
	this.Environment = function(type) {};
	/**
	 * @param {string} type
	 * @return {WshSpecialFolders|string} 
	*/
	this.SpecialFolders = function(type) {};
	this.AppActivate = function() {}
	this.CreateShortcut = function() {}
	/**
	 * @param {string} command
	 * @return {WshScriptExec} 
	*/
	this.Exec = function(command) {}
	/**
	 * @param {string} strString
	 * @return {string} 
	*/
	this.ExpandEnvironmentStrings = function(strString) {}
	this.LogEvent = function() {}
	this.Popup = function() {}
	this.RegDelete = function() {}
	this.RegRead = function(name) {}
	this.RegWrite = function() {}
	this.Run = function() {}
	this.SendKeys = function(value) {} 
};


/** WScript.Network COM object interface
 * @see http://msdn.microsoft.com/en-us/library/s6wt333f%28v=vs.84%29.aspx
 * @constructor
 * @return {WScriptNetwork}
 */
function WScriptNetwork () { 
	this.ComputerName = {};
	this.UserDomain = {};
	this.UserName = {};
	this.AddPrinterConnection = function() {}
	this.AddWindowsPrinterConnection = function() {}
	this.EnumNetworkDrives = function() {}
	this.EnumPrinterConnections = function() {}
	this.MapNetworkDrive = function() {}
	this.RemoveNetworkDrive = function() {}
	this.RemovePrinterConnection = function() {}
	this.SetDefaultPrinter = function() {} 
};
	
