﻿
/** SWbemServices COM object interface
 * @see http://msdn.microsoft.com/en-us/library/s6wt333f%28v=vs.84%29.aspx
 * @constructor
 * @return {SWbemServices}
 */
function SWbemServices () { 
	this.Security_ = {};
	this.AssociatorsOf = function() {}
	this.AssociatorsOfAsync = function() {}
	this.Delete = function() {}
	this.DeleteAsync = function() {}
	this.ExecMethod = function() {}
	this.ExecMethodAsync = function() {}
	this.ExecNotificationQuery = function() {}
	this.ExecNotificationQueryAsync = function() {}
	/**
	 * @param {string} strQuery
	 * @param {string=} strQueryLanguage 
	 * @param {number=} iFlags 
	 * @param {Object=} objwbemNamedValueSet
	*/
	this.ExecQuery = function(strQuery, strQueryLanguage, iFlags, objwbemNamedValueSet) {}
	this.ExecQueryAsync = function() {}
	/**
	 * @param {string} [strQuery]
	*/
	this.Get = function(strQuery) {}
	/**
	 * @param {string} [strQuery]
	*/
	this.GetAsync = function(strQuery) {}
	this.InstancesOf = function() {}
	this.InstancesOfAsync = function() {}
	this.ReferencesTo = function() {}
	this.ReferencesToAsync = function() {}
	this.SubclassesOf = function() {}
	this.SubclassesOfAsync = function() {}
};
	

/** WbemScripting.SWbemLocator COM object interface
 * @see http://msdn.microsoft.com/en-us/library/s6wt333f%28v=vs.84%29.aspx
 * @constructor
 * @return {SWbemLocator}
 */
function SWbemLocator () { 
	this.Security_ = {};
	/**
	 * @param {string=} strServer
	 * @param {string=} strNamespace
	 * @param {string=} strUser
	 * @param {string=} strPassword
	 * @param {string=} strLocale
	 * @param {string=} strAuthority
	 * @param {number=} iSecurityFlags
	 * @param {Object=} objwbemNamedValueSet
	*/
	this.ConnectServer = function(strServer, strNamespace, strUser, strPassword, strLocale, strAuthority, iSecurityFlags, objwbemNamedValueSet) {}
};
	
