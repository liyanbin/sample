﻿
ctx.itemInit('start', {
	type: "button",
	value: "Start",
	style: "success",
	tooltip: 'Click to start',
	tooltipPlacement: 'top',
	icon: 'check',
	//width: 2,
	close: false
});

ctx.itemInit('stop', {
	type: "button",
	value: "Stop",
	style: "danger",
	tooltip: 'Click to stop',
	tooltipPlacement: 'top',
	icon: 'flash',
	disabled: true,
	close: false
});

ctx.itemInit('review', {
	type: "textarea",
	rows: 3,
	value: "中华人民共和国大使馆驻法兰 المملكةالعربيةالسعو  ФедераПОСО ЛЬСТСИЙСКОЙ $ €"
});

ctx.itemInit('login', {
	type: "input",
	style: "text",
	value: ""
});

ctx.itemInit('pwd', {
	type: "input",
	style: "password",
	value: ""
});

ctx.itemInit('mail', {
	type: "input",
	style: "email",
	value: "support@contextor.eu"
});

ctx.itemInit('site', {
	type: "input",
	style: "website",
	value: "www.contextor.eu"
});

ctx.itemInit('id', {
	type: "input",
	style: "text",
	value: "6",
	disabled: true
});



ctx.itemInit('labelDefault', {
	type: "label",
	value: "Default label",
	style: "default",
	badge: 7
});

ctx.itemInit('labelPrimary', {
	type: "label",
	value: "Primary label",
	style: "primary",
	icon: 'flash'
});

ctx.itemInit('labelSuccess', {
	type: "label",
	value: "Success label",
	style: "success"
});

ctx.itemInit('apple', {
	type: "button",
	value: "Apple",
	style: "primary",
	badge: 7
});

ctx.itemInit('samsung', {
	type: "button",
	value: "Samsung",
	style: "success",
	badge: 5
});

ctx.itemInit('sony', {
	type: "button",
	value: "Sony",
	style: "danger",
	badge: 3
});

ctx.itemInit('assure', {
	type: 'datatable',
	options: {
		columns : [
			{ title: "Nom" },
			{ title: "Lien" },
			{ title: "Effet" },
			{ title: "Fin" }
		]
	}
});

ctx.itemInit('cotisation', {
	type: 'datatable',
	options: {
		columns : [
			{ title: "Echéance" },
			{ title: "Montant" },
			{ title: "Date d'encaissement" },
			{ title: "Statut de cotisation" }
		]
	}
});


ctx.itemInit('nav1', {
	type: 'nav',
	style: 'tab',
	effect: 'fade',
	items: {
		home: { value: "Home", active: true, content: "<h5>HOME</h5> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>" },
		menu1: { value: "Menu 1", content: "<h5>Menu 1</h5> <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>" },
		menu2: { value: "Menu 2", content: "<h5>Menu 2</h5> <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>" },
		menu3: { value: "Menu 3", content: "<h5>Menu 3</h5> <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>" },
	}
});

ctx.itemInit('nav2', {
	type: 'nav',
	style: 'pill',
	items: {
		m0: { value: "Success", active: true, content: "<div class=\"alert alert-success\">\
				  <strong>Success!</strong> Indicates a successful or positive action.\
				</div>" },
		m1: { value: "Info", content: "<div class=\"alert alert-info\">\
				  <strong>Info!</strong> Indicates a neutral informative change or action.\
				</div>" },
		m2: { value: "Warning", content: "<div class=\"alert alert-warning\">\
				  <strong>Warning!</strong> Indicates a warning that might need attention.\
				</div>" },
		m3: { value: "Danger", content: "<div class=\"alert alert-danger\">\
				  <strong>Danger!</strong> Indicates a dangerous or potentially negative action.\
				</div>" },
	}
});

ctx.itemInit('list1', {
	type: 'list',
	items: {
		item1: { value: "First item", badge: 10 },
		item2: { value: "Second item", badge: 4 },
		item3: { value: "Third itemddd", badge: 5 }
	}
});

ctx.itemInit('tree1', {
	type: 'treeview',
	options: {
		levels: 5,
	}
});

ctx.itemInit('sel1', {
	type: 'select',
	label: "Select list (select one):",
	options: { 
		value1: "Option 1",
		value2: "Option 2",
		value3: "Option 3",	
		value4: "Option 4"	
	}
});

ctx.itemInit('sel2', {
	type: 'select',
	label: "Mutiple select list (hold shift to select more than one):",
	multiple: true,
	options: { 
		value1: "Choice 1",
		value2: "Choice 2",
		value3: "Choice 3",	
		value4: "Choice 4"	
	}
});

ctx.itemInit('pagination', {
	type: 'pagination',
	options: { 
		val1: "**toto**",
		val2: "2",
		val3: "3",	
		val4: "4",	
		val5: "5"	
	}
});

