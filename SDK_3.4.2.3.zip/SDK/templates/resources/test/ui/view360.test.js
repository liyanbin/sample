﻿// *** data tables ***
ctx.itemGet('assure').setAll([
	[ "Dupond", "Link", "01/02/03", "10/20/30" ],
	[ "Duval", "Link", "01/02/03", "10/20/30" ],
	[ "Smith", "Link", "01/02/03", "10/20/30" ],
	[ "Walter", "Link", "01/02/03", "10/20/30" ],
	[ "Mc Gilly", "Link", "01/02/03", "10/20/30" ]
]);

//var el = $('#cotisation')[0];
//ctx.itemExec(el, 'setAll', [
ctx.itemGet('cotisation').setAll([
	[ "test", "", "", "" ],
	[ "test", "", "", "" ]
]);

// *** treeview ***
/*
see : https://github.com/jonmiles/bootstrap-treeview
*/
var treeData = [
  {
	text: "Parent 1",
	nodes: [
	  {
		text: "Child 1",
		nodes: [
		  {
			text: "Grandchild 1"
		  },
		  {
			text: "Grandchild 2"
		  }
		]
	  },
	  {
		text: "Child 2"
	  }
	]
  },
  {
	text: "Parent 2",
	icon: "glyphicon glyphicon-stop",
	color: "#800000",
	tags: ['8']
  },
  {
	text: "Parent 3",
	icon: "glyphicon glyphicon-play",
	color: "#008000",
	tags: ['4']
  },
  {
	text: "Parent 4",
	tags: ['5']
  },
  {
	text: "Parent 5",
	tags: ['1']
  }
];

ctx.itemGet('tree1').setAll(treeData);
	