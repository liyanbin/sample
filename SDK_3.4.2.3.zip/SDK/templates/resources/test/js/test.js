﻿
var child; // child iframe

$(function() {
	child = window.frames['popup'];
	
});


function initLogin() {
	var obj = {
	    file: "ui/login.html",
		JSFile: 'ui/login.js',
		CSSFile: 'ui/login.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initMenu1() {
	var obj = {
	    file: "ui/menu1.html",
		JSFile: 'ui/menu1.js',
		CSSFile: 'ui/menu1.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm1() {
	var obj = {
	    file: "ui/form1.html",
		JSFile: 'ui/form1.js',
		CSSFile: 'ui/form1.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm2() {
	var obj = {
	    file: "ui/form2.html",
		JSFile: 'ui/form2.js',
		CSSFile: 'ui/form2.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm3() {
	var obj = {
	    file: "ui/form3.html",
		JSFile: 'ui/form3.js',
		CSSFile: 'ui/form3.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm4() {
	var obj = {
	    file: "ui/form4.html",
		JSFile: 'ui/form4.js',
		CSSFile: 'ui/form4.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm5() {
	var obj = {
	    file: "ui/form5.html",
		JSFile: 'ui/form5.js',
		CSSFile: 'ui/form5.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm6() {
	var obj = {
	    file: "ui/form6.html",
		JSFile: 'ui/form6.js',
		CSSFile: 'ui/form6.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm7() {
	var obj = {
	    file: "ui/form7.html",
		JSFile: 'ui/form7.js',
		CSSFile: 'ui/form7.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm8() {
	var obj = {
	    file: "ui/form8.html",
		JSFile: 'ui/form8.js',
		CSSFile: 'ui/form8.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm9() {
	var obj = {
	    file: "ui/form9.html",
		JSFile: 'ui/form9.js',
		CSSFile: 'ui/form9.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm10() {
	var obj = {
	    file: "ui/form10.html",
		JSFile: 'ui/form10.js',
		CSSFile: 'ui/form10.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm11() {
	var obj = {
	    file: "ui/form11.html",
		JSFile: 'ui/form11.js',
		CSSFile: 'ui/form11.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initForm12() {
	var obj = {
	    file: "ui/form12.html",
		JSFile: 'ui/form12.js',
		CSSFile: 'ui/form12.css',
	    autoClose: 10000
	};
	initialize(obj);
}

function initDiagnostic() {
	var obj = {
		appliName: 'GLOBAL',
		pageName: 'pBootbox',
		eventName: 'evNotification',
	    //header: "<b>Issue report</b>",
	    //message: '<b>Bla bla bla...</b><br/>Bla bla bla...<br/><br/>',
	    form: {
            id: 'inputForm',
	        group: [
			{
				row: [{
	                labelDiag: {
						type: "label",
						value: "Diagnostic",
						width: 2,
						tooltip: 'Click to save desktop and Contextor diagnostic'
					}, 
					saveDiag: {
						type: "button",
						submit: true,
						value: "Save",
						icon: "flash",
						tooltip: 'Click to save desktop and Contextor diagnostic',
						width: 2,
						className: "btn-primary"
					}
                }]
			},
			{
				row: [{
	                labelDiag: {
						type: "label",
						value: "Recording",
						width: 2,
					},
	                start: {
						type: "button",
						submit: true,
						value: "Start",
						icon: "play",
						tooltip: 'Click to start recording',
						width: 1,
						className: "btn-success"
					},
	                stop: {
						type: "button",
						submit: true,
						value: "Stop",
						icon: "stop",
						disabled: true,
						visible: false,
						width: 1,
						tooltip: 'Click to stop recording',
						className: "btn-danger"
					}
                }]
			},
			/*{
				label: {
				  value: "",
				  width: 2
				},
				checkbox: {
				  name: "diagOptions[]",
				  value: ["dump"],
				  options: {
					soft: 'Include software list',
					dump: 'Include crash dumps'
				  },
				  width: 9
			    }
	        },*/
			
			
			{
				row: [{
					label: {
					  value: "",
					  width: 2
					},
					recordOptions: {
					  name: "recordOptions[]",
					  type: "checkbox",
					  disabled: true,
					  value: ["screenshot"],
					  width:8,
					  options: {
						screenshot: 'Include screenshots',
						auto: 'Auto-recording (for each scenario)'
					  }
					}
			
				}]
			},
			{
				row: [{
	                labelComment: {
						type: "label",
						value: "Comment",
						width: 2
					}
                },
				{
	                addComment: {
						type: "button",
						submit: true,
						value: "Add comment",
						icon: "pencil",
						tooltip: 'Click to insert a comment<br/> - bla bla bla<br/> - bla bla bla',
						width: 2,
						className: "btn-primary"
					}
                }]
			},
	        {
	            comment: {
					type: "textarea",
	                rows: 10,
	                value: "",
					tooltipPlacement: 'top',
					width: 12
	            }
	        },
			{    
				close: {
					type: "button",
					value: "Close",
					icon: "check",
					tooltip: 'Click to close Issue report window',
					tooltipPlacement: 'top',
					width: 2,
					close: true,
					className: "btn-default"
				}
			},
            ]
        }
	};
	initialize(obj);
}

function initHelp() {
//	initialize({ file: 'ui/help.html' });
	var obj = {
		escape: 'cancel',	
		//message: "<b>Set your login and password</b></br></br>",
		file: 'ui/help.html',
		color: 'yellow',
		form: {
			id: 'inputForm',
			group: [
			{
				labelUsername: {
					type: e.popup.formType.Label,
					value: "Username",
					width: 3
				},
				username: {
					type: e.popup.formType.Text,
					width: 9
				}
			},{
				labelPassword: {
					type: e.popup.formType.Label,
					value: "Password",
					width: 3
				},
				password: {
					type: e.popup.formType.Password,
					width: 9
				}
			} 
			]
		},
		buttons: {
			ok: {	
				label: 'Ok',	
				type: e.popup.buttonStyle.Green,
				submit: true,	
				icon: e.popup.buttonIcon.ok 
			},	
			cancel: {	
				label: 'Cancel',	
				type: e.popup.buttonStyle.Red,
				icon: e.popup.buttonIcon.remove
			}	
		}	
	}
	initialize(obj);
}

function initTooltip() {
	var obj = {
	    message: "<div markdown='1'>\
###I am a tooltip \n\n \
Add extra information below \n\n \
bla bla bla\n\nbla bla bla\n\nbla bla bla</div>",
	    icon: "../bmp64/galaxy.png",
	    //iconSize: 2,
	    //iconWidth: "64px",
	    //iconWidth: "100%",
	    color: "yellow",
	    autoClose: 10000,
		closeOnClick: true,
		classes: {
			'modal-dialog': 'modal-dialog-tooltip',
			'modal-body': 'modal-body-tooltip',
			'icon-class': 'icon-class-tooltip'
		},
		buttons: {}
	};
	initialize(obj);
}

function initCustom() {
	var obj = {
	    file: "ui/customJson.html",
		data:{
			name: 'Smith',
			firstname: 'John',
			age: '39',
			address: '5 rue Guy Moquet',
			zip: '91400',
			city: 'Orsay'
		},
	    //iconWidth: "100%",
	    //iconSize: 3,
	    //title: "<img src='../bmp32/user.png'/>  **Custom title**",
	    icon: "../bmp64/comp6.png",
	    autoClose: 10000,
		color: "yellow",
		escape: 'cancel',
		buttons: {
	        ok: {
		        label: "Ok",
		        type: "warning",
                icon: "check"
	        },
            cancel: {
		        label: "Cancel",
				type: "default",
                icon: "flash"
	        },
	        main: {
		        type: "link",
		        label: "Click ME",
				close: false,
		        icon: "pushpin"
	        }
        }
	};
	initialize(obj);
}

function initCustomHtml() {
	var obj = {
	    file: "ui/custom.html",
		data:{
			name: 'Smith',
			firstname: 'John',
			age: '39',
			address: '5 rue Guy Moquet',
			zip: '91400',
			city: 'Orsay'
		},
	    autoClose: 10000,
		color: "yellow"
	};
	initialize(obj);
}

function initMarkdown() {

	//var title = "<img src='../bmp32/control_start_blue.png' alt='Previous'/><img src='../bmp32/control_end_blue.png' alt='Next'/>";
	var title;
	var obj = {
		file: 'ui/markdown.html',
		data: {
			people: [
			{ name: 'Smith', firstname: 'John', age: '26' },
			{ name: 'Wilde', firstname: 'Jack', age: '41'	},
			{ name: 'Smith', firstname: 'Mary', age: '34'	}
			]
		},
	    title: title,
		//size: 'small'
	};
	initialize(obj);

	//$(".step").hide();
	//$("#p5").show();
}

function initTutorial1() {
	var obj = {
	    //message: message,
		file: 'ui/tutorial1.html'
	};
	initialize(obj);
}

function initTutorial2() {
	var obj = {
	    //message: message,
		file: 'ui/tutorial2.html'
	};
	initialize(obj);
}

function initView360() {
	var obj = {
	    //message: message,
		file: 'ui/view360.html',
		CSSFile: ['../popup/css/bootstrap-datatables.min.css', '../popup/css/bootstrap-treeview.min.css'],
		JSFile: ['../popup/js/bootstrap-datatables.min.js', '../popup/js/bootstrap-treeview.min.js', 'ui/view360.js'],
		testFile: 'ui/view360.test.js'
	};
	initialize(obj);
}

function initContact() {
	var obj = {
	    //message: message,
		file: 'ui/Contact.html'
		//JSFile: 'ui/Contact.js'
	};
	initialize(obj);
}


function initialize(obj) {
	var retry = false;
	// make it an array
	if ('string' === typeof obj.testFile) {
		obj.testFile = [obj.testFile]; 
		retry = true;
	}
	if ('string' === typeof obj.CSSFile) {
		obj.CSSFile = [obj.CSSFile]; 
		retry = true;
	}
	if ('string' === typeof obj.JSFile) {
		obj.JSFile = [obj.JSFile]; 
		retry = true;
	}
	if ('string' === typeof obj.file) {
		obj.file = [obj.file]; 
		retry = true;
	}
	if (retry) {
		initialize(obj);
		return;
	}
	if (obj && obj.testFile && obj.testFile.length) {
		var contentFile = obj.testFile.shift();
		$.ajax({
			url: contentFile,
			//async: false,
			cache: false,
			dataType: "text",
			success: function(content) {
				obj.testContent = obj.testContent || "";
				obj.testContent += "\n\n" + content;
				initialize(obj);
			},
			error: function (ex) {
				var text = "Error: " + contentFile + " : " + ex.statusText;
				alert(text);
				initialize(obj);
			}
		});
	} else if (obj && obj.CSSFile && obj.CSSFile.length) {
		var contentFile = obj.CSSFile.shift();
		$.ajax({
			url: contentFile,
			//async: false,
			cache: false,
			dataType: "text",
			success: function(content) {
				obj.CSSContent = obj.CSSContent || "";
				obj.CSSContent += "\n\n" + content;
				initialize(obj);
			},
			error: function (ex) {
				var text = "Error: " + contentFile + " : " + ex.statusText;
				alert(text);
				initialize(obj);
			}
		});
	} else if (obj && obj.JSFile && obj.JSFile.length) {
		var contentFile = obj.JSFile.shift();
		$.ajax({
			url: contentFile,
			//async: false,
			cache: false,
			dataType: "text",
			success: function(content) {
				obj.initContent = obj.initContent || "";
				obj.initContent += "\n\n" + content;
				initialize(obj);
			},
			error: function (ex) {
				var text = "Error: " + contentFile + " : " + ex.statusText;
				alert(text);
				initialize(obj);
			}
		});
	} else if (obj && obj.file && obj.file.length) {
		var contentFile = obj.file.shift()
		$.ajax({
			url: contentFile,
			//async: false,
			cache: false,
			dataType: "text",
			success: function(content) {
				obj.message = obj.message || "";
				obj.message += "\n\n" + content;
				initialize(obj);
			},
			error: function (ex) {
				var text = "Error: " + contentFile + " : " + ex.statusText;
				alert(text);
			}
		});
	} else {
		child.postMessage(obj, '*');
	}
}
// *** this function is just for testing in standalone mode, inside I.E. ***
//    Simply call it from: $(function() { ... }
/*
function initForm1() {
	var obj = {
	    message: '',
	    header: "<b>Set username and password</b>",
	    color: "blue",
	    form: {
            id: 'inputForm',
	        group: [{
	            label: {
	                value: "Username",
                    width: 3
	            },
                text: {
	                name: "username",
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Password",
                    width: 3
	            },
                password: {
                    name: "password",
	                width: 5
	            }
	        },
	        {
    	        row: [{
                    width: 8,
	                label: {
	                    value: "Movie title"
	                },
	                text: {
	                    name: "title"
	                }
                },
                {
                    width: 4,
                    label: {
                        value: "Genre"
                    },
                    select: {
                        name: "genre",
                        options: {
                            action: 'Action',
                            comedy: 'Comedy',
                            horror: 'Horror',
                            romance: 'Romance'
                        }
                    }
                }]
	        },
	        {
    	        row: [{
                    width: 4,
	                label: {
	                    value: "Director"
	                },
	                text: {
	                    name: "director"
	                }
                },
                {
                    width: 4,
                    label: {
                        value: "Writer"
                    },
	                text: {
	                    name: "writer"
	                }
                },
                {
                    width: 4,
                    label: {
                        value: "Producer"
                    },
	                text: {
	                    name: "producer"
	                }
                }]
	        },
	        {
    	        row: [{
                    width: 6,
	                label: {
	                    value: "Website"
	                },
	                text: {
	                    name: "website"
	                }
                },
                {
                    width: 6,
                    label: {
                        value: "Youtube trailer"
                    },
	                text: {
	                    name: "trailer"
	                }
                }]
	        },
	        {
				width:12,
	            label: {
	                value: "Review"
	            },
	            textarea: {
	                name: "review",
	                rows: 8,
	                value: "中华人民共和国大使馆驻法兰\n المملكةالعربيةالسعو  \nФедераПОСО ЛЬСТСИЙСКОЙ $ €"
	            }
	        },
	        {
                width: 12,
	            label: {
	                value: "Rating"
	            },
	            radio: {
	                name: "rating",
	                value: "watchable",
	                className: "radio-inline",
	                options: {
	                    terrible: 'Terrible',
	                    watchable: 'Watchable',
                        best: 'Best ever'
                    }
	            }
	        },
	        {
	            label: {
	                value: "Genre",
	                width: 3
	            },
	            radio: {
	                name: "gender",
	                value: "male",
	                options: {
	                    male: 'Male',
	                    female: 'Female',
	                    other: 'Other'
	                },
	                width: 8
	            }
	        },
	        {
	            label: {
	                value: "Browser",
	                width: 3
	            },
	            checkbox: {
	                name: "browsers[]",
	                value: ["firefox", "ie"],
	                options: {
	                    chrome: 'Google Chrome',
	                    firefox: 'Firefox',
	                    ie: 'IE',
	                    safari: 'Safari',
	                    opera: 'Opera',
	                    other: 'Other'
	                },
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Cities",
	                width: 3
	            },
	            text: {
	                name: "cities",
	                value: "Paris",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
	            label: {
	                value: "Countries",
	                width: 3
	            },
	            text: {
	                name: "countries",
	                value: "France",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
	            label: {
	                value: "ID",
	                width: 3
	            },
	            text: {
	                name: "id",
	                value: "2",
	                disabled: "disabled",
	                width: 3
	            }
	        },
	        {
	            label: {
	                value: "Email",
	                width: 3
	            },
	            email: {
	                name: "email",
	                value: "support@contextor.eu",
	                control: "email",
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Website",
	                width: 3
	            },
	            text: {
	                name: "website",
	                value: "www.contextor.eu",
	                control: "website",
	                width: 5
	            }
	        }
            ]
        },
		buttons: {
	        Login: {
		        type: "submit",
				className: "btn btn-primary",
                icon: "check"
	        },
            Cancel: {
		        type: "button",
				className: "btn btn-default",
                icon: "flash"
	        }
        }
	};
	initialize(obj);
}


function initForm2() {
	var obj = {
		appliName: 'GLOBAL',
		pageName: 'pBootbox',
		eventName: 'evNotification',
	    message: '',
	    header: "**Set username and password**",
	    form: {
            id: 'inputForm',
	        group: [{
	            label: {
					type: "label",
	                value: "Username",
                    width: 3
	            },
                username: {
					type: "text",
	                width: 5
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Password",
                    width: 3
	            },
                password: {
					type: "password",
	                width: 5
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Review",
					width: 3
	            },
	            review: {
					type: "textarea",
	                rows: 8,
					width: 8,
	                value: "中华人民共和国大使馆驻法兰\n المملكةالعربيةالسعو  \nФедераПОСО ЛЬСТСИЙСКОЙ $ €"
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Cities",
	                width: 3
	            },
	            cities: {
					type: "text",
	                value: "Paris",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Countries",
	                width: 3
	            },
	            countries: {
					type: "text",
	                value: "France",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
				label: {
					type: "label",
					value: "ID",
					width: 3
				},
				id: {
					type: "text",
					value: "6",
					disabled: "disabled",
					width: 2
				},
				start: {
					type: "button",
					value: "Start",
					className: "btn btn-success",
					tooltip: 'Click to start',
					tooltipPlacement: 'top',
					icon: "check",
					close: false,
					width: 2
				},
				stop: {
					type: "button",
					value: "Stop",
					className: "btn btn-danger",
					tooltip: 'Click to stop',
					tooltipPlacement: 'top',
					icon: "flash",
					close: false,
					width: 2
				}
	        },
	        {
	            label: {
					type: "label",
	                value: "Email",
	                width: 3
	            },
	            email: {
					type: "email",
	                value: "support@contextor.eu",
	                control: "email",
	                width: 5
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Website",
	                width: 3
	            },
	            website: {
					type: "text",
	                value: "www.contextor.eu",
	                control: "website",
	                width: 5
	            }
	        }
            ,{
                row:[{
	                offset: 3,
	                width: 5,
	                button: [{
                        type: 'submit',
				        className: "btn btn-primary",
                        value: "Login",
                        icon: "check"
	                },
	                {
				        className: "btn btn-default",
                        value: "Cancel",
                        icon: "flash"
	                }]
                }]
	        }
            ]
        },
		buttons: {
	        login: {
		        type: "submit",
		        value: "Login",
				tooltip: 'Click to submit',
				tooltipPlacement: 'top',
				className: "btn btn-primary",
                icon: "check"
	        },
            cancel: {
		        type: "button",
		        value: "Cancel",
				tooltip: 'Click to cancel',
				tooltipPlacement: 'top',
				className: "btn btn-default",
                icon: "flash"
	        }
        }
	};
	initialize(obj);

}
*/

