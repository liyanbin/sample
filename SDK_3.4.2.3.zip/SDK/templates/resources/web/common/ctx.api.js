﻿/*function guid() {
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
}*/

var ctx = ctx || {};

ctx.api = (function () {
	var _url = '';
	var _token = '';
	var self = {};

	var _callJobApi = function(run, data, callback) {
		if (!_token) {
			if (callback && ('function' === typeof(callback) )) {
				callback(400, "Unauthorized", null);
			}
		}
		
		if (data && ('object' === typeof (data))) {
			if (undefined === data.status) data.status = 'New';
			if (undefined === data.priority) data.priority = 3; //high priority
			if (undefined === data.format) data.format = 'json';
			if (undefined === data.code) data.code = '';
			if (undefined === data.label) data.label = '';
			if (undefined === data.duration) data.duration = 0;
		}
		if (!_url) {
			_url = self.setURL();
		}
		var sData = JSON.stringify(data);
		
		$.ajax({
			type: 'POST',
			url: _url + (run ? '/RunJob' : '/AddJob'),
			contentType: 'application/json',
			headers: {
				Authorization: 'Bearer ' + _token,
			},
			data: sData,
			//crossDomain: true,
			success: function (res, textStatus, jqXHR) {
				try{
					if (res && ('string' === typeof res)) {
						res = JSON.parse(res);
					}
					var job = res.data;
					if (job.dataJson) {
						job.data = job.dataJson;
						delete job.dataJson;
					}
					if (((job.format == 'json') || (!job.format)) && ('string' === typeof job.data)) {
						job.data = JSON.parse(job.data);
					}
					if (callback && ('function' === typeof(callback) )) {
						callback(jqXHR.status, jqXHR.statusText, job);
					}
					
				} catch (ex) {
					callback(null, 'invalid answer format', null);
				}
			},
			error: function (jqXHR, textStatus, errorThrow) {
				if (callback && ('function' === typeof(callback) )) {
					callback(jqXHR.status, jqXHR.statusText, null);
				}
			}
		});
	}

	// Get argument from URL
	var _qs = function(search_for) {
		var query = window.location.search.substring(1);
		var parms = query.toLowerCase().split('&');
		for (var i=0; i< parms.length; i++) {
			var pos = parms[i].indexOf('=');
			if (pos > 0  && search_for == parms[i].substring(0,pos).trim()) {
				return parms[i].substring(pos + 1).trim();
			}
		}
		return "";
	}

	self.setURL = function(url) {
		if (!url) {
			var server = _qs("server");
			if (!server) {
				server = window.location.protocol + (window.location.port ? ':' + window.location.port : '') + '//' + window.location.host;
			}
			var path = _qs("path");
			if (!path) {
				path = "";
				// get server instance name : 'window.location.pathname' is something like '/<instance>/Public/...'
				var query = window.location.pathname.substring(1);
				var pos = query.indexOf('/');
				if (pos > 0 ) {
					path = query.substring(0, pos + 1);
				}
			}
			url = server + '/' + path;
		}
		_url = url + '/galaxyui/_api';
		return _url;
	}

	self.login = function(login, password, callback)
	{
		if (!_url) {
			_url = self.setURL();
		}
		var data = {
			login: login,
			password: password
		};
		$.ajax({
			type: 'POST',
			url: _url + '/Login',
			contentType: 'application/json',
			data: JSON.stringify(data),
			dataType: 'json',
			success: function (res, textStatus, jqXHR) {
				_token = res['access_token'];
				if (callback && ('function' === typeof(callback) )) {
					callback(jqXHR.status, jqXHR.statusText, res);
				}
			},
			error: function (jqXHR, textStatus, errorThrow) {
				if (callback && ('function' === typeof(callback) )) {
					callback(jqXHR.status, jqXHR.statusText, null);
				}
			}
		});
	}

	self.addJob = function(data, callback)
	{
		return _callJobApi(false, data, callback);
	}

	self.runJob = function(data, callback)
	{
		return _callJobApi(true, data, callback);
	}

	return self;	
})()

