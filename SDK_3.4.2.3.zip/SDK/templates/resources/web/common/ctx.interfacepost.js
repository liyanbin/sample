﻿
$(document).ready(function() {

	var showGrid = ctx.queryURL("ShowGrid");
	if (showGrid) {
		ctx.currentPopup._params.showGrid = true;
	}

	var testMode = ctx.queryURL("TestMode");
	if (testMode) {
		ctx.currentPopup._params.testMode = true;
	}
	var designMode = ctx.queryURL("DesignMode");
	if (designMode) {
		ctx.currentPopup._params.designMode = true;
		if (ctx.currentPopup) {
			ctx.currentPopup.open();
		}
		// reinit property display
		ctx.notify("", '_ctxStudioEdit', {}, true);
		
		// update declared items
		ctx.notifyDeclaredItems();
	}

} );



	