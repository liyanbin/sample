
// *********************************
// *** Add needed request models ***
// *********************************

var child; // child M2M iframe
var frameURL;

var ClientID='';
var CtxtProcess='';
var Debug='';
var ProcessName = 'WebPage';


// Get argument from URL
function qs(search_for) {
	var query = window.location.search.substring(1);
	var parms = query.split('&');
	for (var i=0; i<parms.length; i++) {
		var pos = parms[i].indexOf('=');
		if (pos > 0  && search_for == parms[i].substring(0,pos)) {
			return parms[i].substring(pos+1);
		}
	}
	return "";
}

function OnLoad()
{
	ClientID = qs('ClientID');
	// generate a random ClientID with a timestamp
	if (!ClientID) {
		var date = new Date();
		var txt;
		try {
			txt = date.toISOString();
		} catch (ex) {
			try {
				txt = date.toJSON();
			} catch (ex2) {
				txt = date.toUTCString();
			}
		}
		ClientID = 'Web_' + txt;
	}
	if (CtxtProcess == '') CtxtProcess = qs('CtxtProcess');
	Debug=qs('Debug');
	M2MURL=qs('M2MURL');
	if (!M2MURL) M2MURL = 'SignalR';
	// TODO : manage https / http
	frameURL = 'http://' + document.domain + '/' + M2MURL + '/m2m_WEB.htm';

	//document.getElementById('m2mFrame').src = 'http://localhost/SignalR_RD/m2m_WEB.htm?ClientID=' + ClientID + '&Debug=True';
	//document.getElementById('m2mFrame').src = 'http://ns322201.ip-37-187-155.eu/SignalR_RD/m2m_WEB.htm?ClientID=' + ClientID + '&Debug=True';
	var src = frameURL + '?ClientID=' + ClientID + '&Debug=True';
	document.getElementById('m2mFrame').src = src;
	child = window.frames['m2mFrame'];
	if (Debug == 'True')
	{
		document.getElementById('m2mFrame').style.display = 'block';
	} else {
		document.getElementById('m2mFrame').style.display = 'none';
	}
}

function searchNumber() {
    var number = document.getElementById('phoneNumber').value;
    addLog(number);
	child.SendRequest('evSetCaseAut2', {
        uuid: '',
        number: number
    }, ClientID, 'Automate2Client', 'Desktop');
}

function searchTicket() {
    var number = document.getElementById('ticketNumber').value;
    addLog(number);
	child.SendRequest('evSetCaseAut1', {
        uuid: '',
        number: number
    }, ClientID, 'Automate1Client', 'Desktop');
}

function searchAmazon() {
    var search = document.getElementById('amazonRequest').value;
    addLog(search);
	child.SendRequest('evSetCaseAut3', {
        uuid: '',
        search: search
    }, ClientID, 'Automate3Client', 'Desktop');
}

function searchSalesforce() {
    var search = document.getElementById('salesforceRequest').value;
    addLog(search);
	child.SendRequest('evGetContactAut4', {
        search: search
    }, ClientID, 'Automate4Client', 'Desktop');
}

function searchAccountSalesforce() {
    var search = document.getElementById('salesforceAccountRequest').value;
    addLog(search);
	child.SendRequest('evGetAccountAut4', {
        search: search
    }, ClientID, 'Automate4Client', 'Desktop');
}

function searchAttachmate() {
    var search = document.getElementById('attachmateRequest').value;
    addLog(search);
	child.SendRequest('evGetContactAut5', {
        search: search
    }, ClientID, 'Automate5Client', 'Desktop');
}

function searchCalendarAttachmate() {
    var search = document.getElementById('attachmateCalendarRequest').value;
    addLog(search);
	child.SendRequest('evGetCalendarAut5', {
        search: search
    }, ClientID, 'Automate5Client', 'Desktop');
}

function pingHub() {
    addLog('pingHub');
    // call ping mechanism
    var code = PingHub(ClientID, ProcessName );
}

var parent = this;

parent.initM2M = function () {
    addLog('initM2M');
}

parent.ReceivePingAnswer = function () {
    addLog('ReceivePingAnswer');
}

parent.ReceiveRequest = function (strSender, req) {
    /*TBC
	switch (req.ev.name) { ... }
	*/
}

parent.ReceiveAnswer = function (req) {
    switch (req.ev.name) {
        case 'evUpdateCaseAut1':
            var txt = "Id: " + req.data.id + "<br/>Summary: " + req.data.summary + "<br/>Reporter: " + req.data.reporter + "<br/>Priority: " + req.data.priority + "<br/>Project: " + req.data.project + "<br/>Category: " + req.data.category;
            $('#ticketResult').html(txt);
            break;
        case 'evUpdateCaseAut2':
            var txt = "Number: " + req.data.number + "<br/>Company: " + req.data.company + "<br/>Address: " + req.data.address + "<br/>Category: " + req.data.category;
            $('#numberResult').html(txt);
            break;
        case 'evUpdateCaseAut3':
			$("#amazonResultList").empty();
            for (var i in req.data.results) {
                var obj = req.data.results[i];
				/*
				<li><a href="#">
					<img src="../_assets/img/album-bb.jpg">
					<h2>Broken Bells</h2>
					<p>Broken Bells</p></a>
					<a href="#purchase" data-rel="popup" data-position-to="window" data-transition="pop">Purchase album</a>
				</li>
				*/
                //txt = txt + obj.title + " (" + obj.author + ") : " + obj.price + "<br/>";
				$('#amazonResultList').append($('<li/>'
				).append($('<a/>', {    //here appending `<a>` into `<li>`
					'href': '#'
				}).append($('<img/>', {    //here appending `<img>` into `<a>`
					'src': obj.image
				})).append($('<h2/>', {    //here appending `<h2>` into `<a>`
					'text': obj.title
				})).append($('<p/>', {    //here appending `<p>` into `<a>`
					'text': obj.author
				}))).append($('<a/>', {    //here appending `<a>` into `<li>`
					'href': '#purchase',
					'data-rel': 'popup',
					'data-position-to': "window",
					'data-transition': "pop",
					'text': 'Purchase'
				})));
            }
			$('#amazonResultList').listview('refresh');
            /*var txt = "Answers to search '" + req.data.search + "' :<br/>";
            for (var i in req.data.results) {
                var obj = req.data.results[i];
                txt = txt + obj.title + " (" + obj.author + ") : " + obj.price + "<br/>";
            }
            $('#amazonResult').html(txt);*/
            break;
        case 'evGetContactAut4':
            var txt = "Answers to search '" + req.data.search + "' :<br/>";
            for (var i in req.data.results) {
                var obj = req.data.results[i];
				txt = txt + "Name: " + obj.name + "<br/>Firstname: " + obj.firstname + "<br/>Title: " + obj.title + "<br/>Account: " + obj.account + "<br/>Phone: " + obj.phone + "<br/>Mobile: " + obj.mobile + "<br/>Email: " + obj.email + "<br/>Address: " + obj.address + ' ' + obj.code + ' ' + obj.city + ' ' + obj.country + "<br/><br/>";
            }
            $('#salesforceResult').html(txt);
            break;
        case 'evGetAccountAut4':
            var txt = "Answers to search '" + req.data.search + "' :<br/>";
            for (var i in req.data.results) {
                var obj = req.data.results[i];
				txt = txt + "Name: " + obj.name + "<br/>Type: " + obj.type + "<br/>Web site: " + obj.webSite + "<br/>Description: " + obj.description + "<br/>Phone: " + obj.phone + "<br/>Employees: " + obj.employees + "<br/>Industry: " + obj.industry + "<br/>Address: " + obj.address + ' ' + obj.code + ' ' + obj.city + ' ' + obj.country + "<br/><br/>";
            }
            $('#salesforceResult').html(txt);
            break;
        case 'evGetContactAut5':
            //var txt = "Answers to search '" + req.data.search + "' :<br/>";
			$("#attachmateResultList").empty();
            for (var i in req.data.results) {
                var obj = req.data.results[i];
				$("#attachmateResultList")
				.append($('<li/>', {
					html:"Name: <b>" + obj.name + "</b>"
				}))
				.append($('<li/>', {
					html:"Id: <b>" + obj.id + "</b>"
				}))
				.append($('<li/>', {
					html:"Company: <b>" + obj.company + "</b>"
				}))
				.append($('<li/>', {
					html:"Address: <b>" + obj.address + ' ' + obj.address2 + ' ' + obj.code + ' ' + obj.city + "</b>"
				}));
            }
            $('#attachmateResult').html(txt);
            break;
        case 'evGetCalendarAut5':
			$("#attachmateResultList").empty()
			.append($('<tr/>')).append($('<td/>', {
				html:"Name: <b>" + req.data.name + "</b>"
			}))
			.append($('<tr/>')).append($('<td/>', {
				html:"Date: <b>" + req.data.date + "</b>"
			}))
			;
            for (var i in req.data.results) {
                var obj = req.data.results[i];
				$('#attachmateResultList')
				.append($('<li/>', {
					html: "    " + obj.begin + "/" + obj.end + ": <b>" + obj.description + "</b>"
				}));
            }
			//$('#attachmateResultList').listview('refresh');
            /*var txt = "Name: " + req.data.name + "Date: " + req.data.date + "' :<br/>";
            for (var i in req.data.results) {
                var obj = req.data.results[i];
				txt = txt + "  - " + obj.begin + "/" + obj.end + ": " + obj.description + "<br/>";
            }
            $('#attachmateResult').html(txt);*/
            break;
        case 'evSetCaseAut1':
        case 'evSetCaseAut2':
        case 'evSetCaseAut3':
        default:
            break;
    }
}

parent.HubEvent = function (strEventName) {
    addLog('HubEvent(' + strEventName + ')');
}

addLog = function (txt) {
    child.addLog(txt);
}

