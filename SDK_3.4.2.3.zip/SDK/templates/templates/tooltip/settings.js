﻿popup = POPUPS.%NAME% = POPUPS.popup({ %NAME% : {
  template : e.popup.template.None,
  url : "%NAME%\\popup.html",
  X : e.popup.position.Center,
  Y : e.popup.position.Center
}});

POPUPS.%NAME%.onTest(function(popup) {	
	// TODO : add your tests here
});

