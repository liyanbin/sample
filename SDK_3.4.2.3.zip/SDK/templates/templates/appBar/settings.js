﻿popup = POPUPS.%NAME% = POPUPS.popup({ %NAME% : {
	template: e.popup.template.AppBar,
	url : "%NAME%\\popup.html",
	IEHost: false,
	X : e.popup.position.Right,
	Y : e.popup.position.Center
}});

POPUPS.%NAME%.onTest(function(popup) {	
	// TODO : add your tests here
});

