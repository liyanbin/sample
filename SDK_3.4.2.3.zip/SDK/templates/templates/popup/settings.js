﻿popup = POPUPS.%NAME% = POPUPS.popup({ %NAME% : {
	template : e.popup.template.NoButton,
	url : "%NAME%\\popup.html",
	CX: 500,
	CY: 300,
	X : e.popup.position.Center,
	Y : e.popup.position.Center
}});

POPUPS.%NAME%.onTest(function(popup) {	
	// TODO : add your tests here
});

